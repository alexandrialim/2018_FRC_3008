package org.usfirst.frc.team3008.robot;
import org.usfirst.frc.team3008.robot.Robot;

//import edu.wpi.first.wpilibj.GenericHID;  // for joystick
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Spark;
import org.usfirst.frc.team3008.robot.Variables;

public class Drive implements Variables {
	Joystick joy1;
	
	//setting sparks for motors:
    static Spark FR = new Spark(frontRightDrive);	// Spark for Front Right Motor
    static Spark FL = new Spark(frontLeftDrive);	// Spark for Front Left Motor
    static Spark BR = new Spark(backRightDrive);	// Spark for Back Right Motor
    static Spark BL = new Spark(backLeftDrive);		// Spark for Back Left Motor
    static Spark h = new Spark(hand); 				// Spark for Hand Motor
    
    // Set all motors to start at 0:
    double FR2=0;
    double FL2=0;
    double BR2=0;
    double BL2=0;
    double h2 = 0;
    
    //Run Teleop Code:
    public void run(){
    	joy1 = new Joystick(0);
    	while (true){
			if (joy1.getRawButton(6))FR.set(-1); // FR motor (change later)
			else FR.set(0);
    		    	//(look in RobotDrive.class)			
    	}
    }
}
